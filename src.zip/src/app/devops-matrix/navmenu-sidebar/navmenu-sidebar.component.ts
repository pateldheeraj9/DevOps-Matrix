import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navmenu-sidebar',
  templateUrl: './navmenu-sidebar.component.html',
  styleUrls: ['./navmenu-sidebar.component.css']
})
export class NavMenuSideBarComponent {
}
