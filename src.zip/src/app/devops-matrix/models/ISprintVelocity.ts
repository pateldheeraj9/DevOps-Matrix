export interface ISprintVelocity {
  sprintUID?: string;
  sprintNumber?: string;
  sprintName?: string;
  totalPoints: number;
  developerCount: number;
}
