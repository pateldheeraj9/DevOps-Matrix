export interface ICompletedTasks {
    date: string;
    count: number;
}