export interface IUser {
    EmpName: string;
    EmpId: number;
    EmpEmail:string;
}