import { Component, OnInit } from '@angular/core';
import { CalendarModule } from 'primeng/calendar';

@Component({
  selector: 'ngPrimeComponent',
  templateUrl: './ngPrime.component.html',
  styleUrls: ['./ngPrime.component.css']
})
export class NgPrimeComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}
